import 'dart:convert'; import 'package:http/http.dart' as http; import 'package:shared_preferences/shared_preferences.dart';
class Api {
  static String base = const String.fromEnvironment('API_BASE', defaultValue: 'http://10.0.2.2:8787');
  static Future<String> _token() async => (await SharedPreferences.getInstance()).getString('token') ?? '';
  static Future<String?> getToken() async => (await SharedPreferences.getInstance()).getString('token');
  static Future<void> _setToken(String t) async => (await SharedPreferences.getInstance()).setString('token', t);
  static Future<dynamic> _get(String path) async { final t = await _token(); final res = await http.get(Uri.parse('$base$path'), headers:{'Authorization':'Bearer $t'}); if(res.statusCode==200) return jsonDecode(res.body); return null; }
  static Future<dynamic> _post(String path, Map body, {bool auth=true}) async {
    final headers={'Content-Type':'application/json'}; if(auth) headers['Authorization']='Bearer ${await _token()}';
    final res = await http.post(Uri.parse('$base$path'), headers: headers, body: jsonEncode(body));
    if(res.statusCode==200) return jsonDecode(res.body);
    try{ return jsonDecode(res.body);}catch(_){ return {'error':res.body}; }
  }
  static Future<dynamic> register(String email, String password, String name) async { final r = await _post('/api/auth/register', {'email':email,'password':password,'name':name}, auth:false); if(r is Map && r['token']!=null){ await _setToken(r['token']); return true; } return r?['error']?.toString() ?? false; }
  static Future<dynamic> login(String email, String password) async { final r = await _post('/api/auth/login', {'email':email,'password':password}, auth:false); if(r is Map && r['token']!=null){ await _setToken(r['token']); return true; } return r?['error']?.toString() ?? false; }
  static Future<void> logout() async { await _setToken(''); }
  static Future<Map<String,dynamic>?> currentUser() async { final t = await getToken(); return t!=null && t.isNotEmpty ? {'email':'(hidden)','name':'Student'} : null; }
  static Future<Map<String,dynamic>?> summarizeAndSave(String subject, String content, String level) async { return await _post('/api/notes/summarize', {'subject':subject,'content':content,'level':level}); }
  static Future<List<dynamic>?> listNotes() async { final r=await _get('/api/notes'); return r?['notes'] as List<dynamic>?; }
  static Future<Map<String,dynamic>?> generateQuizAndSave(String subject, String notes, int count) async { return await _post('/api/quiz/generate', {'subject':subject,'notes':notes,'count':count}); }
  static Future<List<dynamic>?> listQuizzes() async { final r=await _get('/api/quiz'); return r?['quizzes'] as List<dynamic>?; }
  static Future<Map<String,dynamic>?> buildPlanAndSave(DateTime exam, String topicsCsv, double hoursPerDay) async { final topics = topicsCsv.split(',').map((e)=>e.trim()).where((e)=>e.isNotEmpty).toList(); return await _post('/api/plan/build', {'examDate': exam.toIso8601String().split('T').first, 'topics': topics, 'hoursPerDay': hoursPerDay}); }
  static Future<List<dynamic>?> listPlans() async { final r=await _get('/api/plan'); return r?['plans'] as List<dynamic>?; }
  static Future<Map<String,dynamic>?> askAndSave(String question, String mode) async { return await _post('/api/chat', {'question':question,'mode':mode}); }
  static Future<List<dynamic>?> listChats() async { final r=await _get('/api/chat'); return r?['messages'] as List<dynamic>?; }
}
