import 'package:flutter/material.dart'; import '../services/api.dart';
class ChatScreen extends StatefulWidget{ const ChatScreen({super.key}); @override State<ChatScreen> createState()=>_ChatScreenState(); }
class _ChatScreenState extends State<ChatScreen>{
  final q=TextEditingController(); String mode='simple'; bool loading=false; String? answer; List<dynamic> history=[];
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { history = await Api.listChats() ?? []; setState((){}); }
  @override Widget build(BuildContext c){
    return Padding(padding: const EdgeInsets.all(16), child: Column(children:[
      DropdownButtonFormField(value: mode, items: const [
        DropdownMenuItem(value:'simple', child: Text('Simple')),
        DropdownMenuItem(value:'detailed', child: Text('Detailed')),
        DropdownMenuItem(value:'example', child: Text('With Example')),
      ], onChanged:(v)=>setState(()=>mode=v as String), decoration: const InputDecoration(labelText:'Mode')),
      const SizedBox(height:8),
      TextField(controller:q, minLines:2, maxLines:4, decoration: const InputDecoration(border: OutlineInputBorder(), labelText:'Ask a question')),
      const SizedBox(height:8),
      FilledButton.icon(onPressed: loading? null : () async {
        setState(()=>loading=true);
        final msg = await Api.askAndSave(q.text, mode);
        setState((){ loading=false; answer = msg?['message']?['answer'] ?? msg?['answer']; });
        _load();
      }, icon: const Icon(Icons.send), label: Text(loading? 'Thinking...' : 'Ask & Save')),
      const SizedBox(height:12),
      if(answer!=null) Expanded(child: SingleChildScrollView(child: SelectableText(answer!)))
      else Expanded(child: ListView(children:[ const Text('History'), for(final m in history) ListTile(title: Text(m['question']??''), subtitle: Text((m['answer']??'').toString().substring(0, (m['answer']??'').toString().length.clamp(0,100)))) ]))
    ]));
  }
}
