import 'package:flutter/material.dart';
import '../services/api.dart';
import 'home_screen.dart';

class AuthGate extends StatefulWidget { const AuthGate({super.key}); @override State<AuthGate> createState()=>_AuthGateState(); }
class _AuthGateState extends State<AuthGate> {
  String? token;
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { token = await Api.getToken(); setState((){}); }
  @override Widget build(BuildContext context){
    if(token==null) return const Scaffold(body: Center(child:CircularProgressIndicator()));
    if(token!.isEmpty) return const AuthScreen();
    return const HomeScreen();
  }
}

class AuthScreen extends StatefulWidget { const AuthScreen({super.key}); @override State<AuthScreen> createState()=>_AuthScreenState(); }
class _AuthScreenState extends State<AuthScreen> {
  final email=TextEditingController(), password=TextEditingController(), name=TextEditingController();
  bool isLogin=true, loading=false; String? error;
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: const Text('Sign in to EduTwin+')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(children: [
          if(!isLogin) TextField(controller:name, decoration: const InputDecoration(labelText:'Name')),
          const SizedBox(height:8),
          TextField(controller:email, decoration: const InputDecoration(labelText:'Email')),
          const SizedBox(height:8),
          TextField(controller:password, decoration: const InputDecoration(labelText:'Password'), obscureText:true),
          const SizedBox(height:8),
          if(error!=null) Text(error!, style: const TextStyle(color: Colors.red)),
          Row(children:[
            TextButton(onPressed: ()=>setState(()=>isLogin=!isLogin), child: Text(isLogin?'Create account':'I have an account')),
            const Spacer(),
            FilledButton(
              onPressed: loading?null:() async{
                setState(()=>loading=true);
                final ok = isLogin ? await Api.login(email.text, password.text) : await Api.register(email.text, password.text, name.text);
                setState(()=>loading=false);
                if(ok==true && mounted){ Navigator.of(context).pushReplacement(MaterialPageRoute(builder:(_)=>const HomeScreen())); }
                else { setState(()=>error = ok is String ? ok : 'Auth failed'); }
              },
              child: Text(loading? 'Please wait...' : (isLogin? 'Login':'Register')),
            )
          ])
        ]),
      ),
    );
  }
}
