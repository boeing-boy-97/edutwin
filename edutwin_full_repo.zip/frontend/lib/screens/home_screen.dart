import 'package:flutter/material.dart';
import 'notes_screen.dart'; import 'quiz_screen.dart'; import 'plan_screen.dart'; import 'chat_screen.dart'; import 'profile_screen.dart';
class HomeScreen extends StatefulWidget{ const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen>{
  int i=0; final pages = const [NotesScreen(), QuizScreen(), PlanScreen(), ChatScreen(), ProfileScreen()];
  @override Widget build(BuildContext c){
    return Scaffold(
      appBar: AppBar(title: const Text('EduTwin+')),
      body: pages[i],
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        onDestinationSelected: (v)=>setState(()=>i=v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.notes_outlined), label:'Notes'),
          NavigationDestination(icon: Icon(Icons.quiz_outlined), label:'Quiz'),
          NavigationDestination(icon: Icon(Icons.event_note_outlined), label:'Plan'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label:'Buddy'),
          NavigationDestination(icon: Icon(Icons.person_outline), label:'Profile'),
        ],
      ),
    );
  }
}
