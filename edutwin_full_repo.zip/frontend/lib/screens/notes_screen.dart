import 'package:flutter/material.dart'; import '../services/api.dart';
class NotesScreen extends StatefulWidget{ const NotesScreen({super.key}); @override State<NotesScreen> createState()=>_NotesScreenState(); }
class _NotesScreenState extends State<NotesScreen>{
  final content=TextEditingController(), subject=TextEditingController(); String level='simple'; bool loading=false; String? result; List<dynamic> history=[];
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { history = await Api.listNotes() ?? []; setState((){}); }
  @override Widget build(BuildContext c){
    return Padding(padding: const EdgeInsets.all(16), child: ListView(children:[
      TextField(controller: subject, decoration: const InputDecoration(labelText:'Subject/topic')),
      const SizedBox(height:8),
      DropdownButtonFormField(value: level, items: const [
        DropdownMenuItem(value:'simple', child: Text('Simple')),
        DropdownMenuItem(value:'detailed', child: Text('Detailed')),
        DropdownMenuItem(value:'mindmap', child: Text('Mind map')),
      ], onChanged:(v)=>setState(()=>level=v as String), decoration: const InputDecoration(labelText:'Style')),
      const SizedBox(height:8),
      TextField(controller: content, minLines:6, maxLines:12, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Paste study content')),
      const SizedBox(height:8),
      FilledButton.icon(onPressed: loading? null : () async {
        setState(()=>loading=true);
        final note = await Api.summarizeAndSave(subject.text, content.text, level);
        setState((){ loading=false; result = note?['note']?['summary'] ?? note?['summary']; });
        _load();
      }, icon: const Icon(Icons.auto_fix_high), label: Text(loading? 'Generating...' : 'Generate & Save')),
      const SizedBox(height:12),
      if(result!=null) Card(child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(result!))),
      const SizedBox(height:12),
      const Text('Recent Notes'),
      for(final n in history) ListTile(title: Text(n['subject']??''), subtitle: Text(((n['summary']??'') as String).padRight(1).substring(0, ((n['summary']??'') as String).length.clamp(0,100))))
    ]));
  }
}
