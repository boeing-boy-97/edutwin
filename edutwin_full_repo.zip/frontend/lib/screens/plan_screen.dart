import 'package:flutter/material.dart'; import '../services/api.dart';
class PlanScreen extends StatefulWidget{ const PlanScreen({super.key}); @override State<PlanScreen> createState()=>_PlanScreenState(); }
class _PlanScreenState extends State<PlanScreen>{
  final topics=TextEditingController(); DateTime exam=DateTime.now().add(const Duration(days:30)); double hours=2; bool loading=false; String? jsonOut; List<dynamic> history=[];
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { history = await Api.listPlans() ?? []; setState((){}); }
  @override Widget build(BuildContext c){
    return Padding(padding: const EdgeInsets.all(16), child: ListView(children:[
      TextField(controller: topics, decoration: const InputDecoration(labelText:'Topics (comma separated)')),
      const SizedBox(height:8),
      Row(children:[ const Text('Hours/day:'), Expanded(child: Slider(value: hours, min:0.5, max:8, divisions:15, label: hours.toStringAsFixed(1), onChanged:(v)=>setState(()=>hours=v))) ]),
      Row(children:[ Expanded(child: Text('Exam: ${exam.toLocal().toString().split(' ').first}')), TextButton(onPressed: () async {
        final p = await showDatePicker(context:c, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days:365)), initialDate: exam);
        if(p!=null) setState(()=>exam=p);
      }, child: const Text('Pick date')) ]),
      const SizedBox(height:8),
      FilledButton.icon(onPressed: loading? null : () async {
        setState(()=>loading=true);
        final plan = await Api.buildPlanAndSave(exam, topics.text, hours);
        setState((){ loading=false; jsonOut = plan?['plan']?['json'] ?? plan?['json']; });
        _load();
      }, icon: const Icon(Icons.event_available_outlined), label: Text(loading? 'Building...' : 'Build & Save')),
      const SizedBox(height:12),
      if(jsonOut!=null) Card(child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(jsonOut!))),
      const SizedBox(height:12),
      const Text('Saved Plans'),
      for(final p in history) ListTile(title: Text('Exam: ${(p['examDate']??'').toString().split('T').first} • ${p['hoursPerDay']}h/day'), subtitle: Text((p['json']??'').toString().substring(0, (p['json']??'').toString().length.clamp(0,100))))
    ]));
  }
}
