import 'package:flutter/material.dart'; import '../services/api.dart';
class QuizScreen extends StatefulWidget{ const QuizScreen({super.key}); @override State<QuizScreen> createState()=>_QuizScreenState(); }
class _QuizScreenState extends State<QuizScreen>{
  final notes=TextEditingController(), subject=TextEditingController(); int count=10; bool loading=false; String? jsonOut; List<dynamic> history=[];
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { history = await Api.listQuizzes() ?? []; setState((){}); }
  @override Widget build(BuildContext c){
    return Padding(padding: const EdgeInsets.all(16), child: ListView(children:[
      TextField(controller: subject, decoration: const InputDecoration(labelText:'Subject/topic')),
      const SizedBox(height:8),
      Row(children:[ const Text('Count:'), const SizedBox(width:8),
        DropdownButton<int>(value: count, items: const [5,10,15,20,25,30].map((e)=>DropdownMenuItem(value:e, child: Text('$e'))).toList(), onChanged:(v)=>setState(()=>count=v??10)), ]),
      const SizedBox(height:8),
      TextField(controller: notes, minLines:6, maxLines:12, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Paste notes')),
      const SizedBox(height:8),
      FilledButton.icon(onPressed: loading? null : () async {
        setState(()=>loading=true);
        final quiz = await Api.generateQuizAndSave(subject.text, notes.text, count);
        setState((){ loading=false; jsonOut = quiz?['quiz']?['json'] ?? quiz?['json']; });
        _load();
      }, icon: const Icon(Icons.quiz_outlined), label: Text(loading? 'Generating...' : 'Generate & Save')),
      const SizedBox(height:12),
      if(jsonOut!=null) Card(child: Padding(padding: const EdgeInsets.all(16), child: SelectableText(jsonOut!))),
      const SizedBox(height:12),
      const Text('Saved Quizzes'),
      for(final q in history) ListTile(title: Text(q['subject']??''), subtitle: Text((q['json']??'') is String ? (q['json'] as String).substring(0, (q['json'] as String).length.clamp(0,100)) : ''))
    ]));
  }
}
