import 'package:flutter/material.dart'; import '../services/api.dart'; import 'auth_screen.dart';
class ProfileScreen extends StatefulWidget{ const ProfileScreen({super.key}); @override State<ProfileScreen> createState()=>_ProfileScreenState(); }
class _ProfileScreenState extends State<ProfileScreen>{
  String? email; String? name;
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { final u = await Api.currentUser(); setState((){ email = u?['email']; name = u?['name']; }); }
  @override Widget build(BuildContext c){
    return Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
      Text('Account', style: Theme.of(c).textTheme.titleLarge),
      const SizedBox(height:8),
      Text('Name: ${name ?? '-'}'),
      Text('Email: ${email ?? '-'}'),
      const Spacer(),
      FilledButton(onPressed: () async { await Api.logout(); if(!mounted) return; Navigator.of(c).pushAndRemoveUntil(MaterialPageRoute(builder:(_)=>const AuthScreen()), (r)=>false); }, child: const Text('Log out'))
    ]));
  }
}
