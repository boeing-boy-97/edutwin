import { Router } from 'express';
import { prisma } from '../services/db.js';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

export const authRouter = Router();
const Register = z.object({ email: z.string().email(), password: z.string().min(6), name: z.string().optional() });
const Login = z.object({ email: z.string().email(), password: z.string().min(6) });

authRouter.post('/register', async (req, res) => {
  const p = Register.safeParse(req.body);
  if(!p.success) return res.status(400).json({error:p.error.flatten()});
  const { email, password, name } = p.data;
  const exists = await prisma.user.findUnique({ where: { email } });
  if(exists) return res.status(409).json({ error: 'Email already registered' });
  const hash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({ data: { email, password: hash, name } });
  const token = jwt.sign({ sub: user.id, email }, process.env.JWT_SECRET || 'dev', { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email: user.email, name: user.name } });
});

authRouter.post('/login', async (req, res) => {
  const p = Login.safeParse(req.body);
  if(!p.success) return res.status(400).json({error:p.error.flatten()});
  const { email, password } = p.data;
  const user = await prisma.user.findUnique({ where: { email } });
  if(!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password);
  if(!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ sub: user.id, email }, process.env.JWT_SECRET || 'dev', { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email: user.email, name: user.name } });
});
